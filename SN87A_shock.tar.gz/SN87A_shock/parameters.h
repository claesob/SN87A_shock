      integer md,mdp1,nl,nlp1,nfel,ncr,nio,ne1,ne2,ne3
	PARAMETER (MD=350,MDP1=MD+1)
c      PARAMETER (MD=3000,MDP1=MD+1)
      PARAMETER (NL=340,NLP1=NL+1)
      PARAMETER (NFEL=3000)
      PARAMETER (ncr=120)
      PARAMETER (nio=ncr)
c      PARAMETER (NE1=-700,NE2=500,NE3=NE2+1)
      PARAMETER (NE1=-250,NE2=500,NE3=NE2+1)      
